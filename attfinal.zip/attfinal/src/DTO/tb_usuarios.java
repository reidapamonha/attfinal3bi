
package DTO;

/**
 *
 * @author Áurea
 */
public class tb_usuarios {
    private String TipoUsuario,Nome;
    private String senha;

    /**
     * @return the TipoUsuário
     */
    public String getTipoUsuario() {
        return TipoUsuario;
    }

    /**
     * @param TipoUsuario the TipoUsuário to set
     */
    public void setTipoUsuario(String TipoUsuario) {
        this.TipoUsuario = TipoUsuario;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param Senha the Senha to set
     */
    public void setSenha(String Senha) {
        this.senha = Senha;
    }
    
    
}
