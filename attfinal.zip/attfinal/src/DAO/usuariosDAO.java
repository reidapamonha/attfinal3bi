
package DAO;

import DTO.tb_usuarios;
import attfinal.ConexaoDAO;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Connection;

/**
 *
 * @author aurea.scarminato
 */
public class usuariosDAO {
   
    Connection conn;
    PreparedStatement pstm;
    
            
    public void cadastarUsuario(tb_usuarios objusuariosdto){
    String sql = "insert into tb_usuarios (Nome, senha, TipoUsuario) values(?, ?, ?)";
    
    conn = (Connection) new ConexaoDAO().conectaBD();
    
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objusuariosdto.getNome());
            pstm.setString(2, objusuariosdto.getSenha());
            
            pstm.execute();
            pstm.close();
            
        } catch (Exception erro) {
            
            JOptionPane.showMessageDialog(null, "usuariosDAO" + erro);
        }
   } 
    
}
